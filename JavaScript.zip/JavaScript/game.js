
//const number randomNumber=
const min = 0;
const max = 1000000;
const randomnumber = getrandomInt(min, max);

function getrandomInt(min, max)  {
    const minCeiled = Math.ceil(min);
    const maxFloored = Math.floor(max);
    return Math.floor(Math.random() * (maxFloored - minCeiled) + minCeiled); 
  };

let counter = 0;
const limit = 20;
console.log(randomnumber);
console.log('Gondoltam egy számra 0 és 1millió között, találd ki mi az! MAX 20 TIPP!!!');
    while(limit>counter){   
        let guess = parseInt(prompt('Tipp:'));
        if(guess!=randomnumber){
            if(guess>randomnumber){
            alert('Nem találtad el! A szám nagyobb mint az általam kitalált!');
            counter++;
        }
            else  if(guess<randomnumber){
                alert('Nem találtad el! A szám kisebb mint az általam kitalált!');
                counter++;}
        }
        else{
            alert('Gratulálok, kitaláltad! Tippjeid száma:', counter);
            break;
        }
        if(limit <= counter){
            alert('Elérted a max limitet, nem tippelhetsz többet! Az én számom:', randomnumber);
        }
        console.log(counter);
        console.log(guess);
    }




