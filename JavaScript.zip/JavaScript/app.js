console.log('Hello world!');

let variable = 15;
variable = 'str';
variable = false;

const constant = 15;


const randomNum=Math.random();

//elágazások
const userName = ' ';
if (userName){
    console.log('Felhasználónév:', userName);
}
else{
    console.log('Nincs felhasználónév');
}

// tömbök
const values = ['red', 'blue', 0, false, [], null];

for (let i = 0; i < values.length; i++) {
    console.log(values[i]);
}

//for-in ciklus

for(const index in values) {
    if (index % 2 == 1){
        console.log(values[index]);
    }
}

//for-of ciklus
for(const value of values){
    console.log(value);
}

//transzformációs metódusok: map,filter
const exchangeRates = [398, 415, 404, 411, 399, 406, 420];

//egyes hónapokban hány eurót ért 1500 FT?
const euros=exchangeRates.map((rate) => 1500/rate);
console.log(euros);

//milyen 400 ft alatti árfolyamok voltak?
const below400 = exchangeRates.filter((rate) => rate<400);
console.log(below400);

function greet(name) {
    console.log('Hello', name);
}

greet(' Váczi Béla');

function square(num){
    return num*num;
}
console.log(square(2));

//objektumok

const person = {
    name: 'Váczi Béla',
    age: 75,
    active: true,
    awards: ['Gólkirály', 'Aranylabda'],
    greet: function() {
        console.log('Hello, ', this.name);
    }
}

person.greet();

