document.addEventListener('DOMContentLoaded', () => {
    const submitBtn = document.querySelector('#submit-btn');
    const tasksList = document.querySelector('#tasks');
    const newTaskInput = document.querySelector('#new-task');

    submitBtn.addEventListener('click', () => {
        const taskText = newTaskInput.value.trim();

        if (taskText !== '') {
            const taskItem = document.createElement('li');
            taskItem.textContent = taskText;

            taskItem.addEventListener('click', () => {
                taskItem.classList.toggle('completed');
            });

            tasksList.appendChild(taskItem);
            newTaskInput.value = '';
        }
    });

    newTaskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            submitBtn.click();
        }
    });
});