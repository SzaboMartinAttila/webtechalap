const GITHUB_ACCESS_TOKEN = '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';

function loadNavigation() {
    fetch('nav.html').then(res => res.text()).then(data => {
        const body = document.querySelector('body');
        body.insertAdjacentHTML('afterbegin', data);
    }).catch(err => console.error(err));
}

loadNavigation();